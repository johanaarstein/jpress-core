<?php
$time = $_SERVER['REQUEST_TIME'];
$timeout_duration = 1800;
